#!/usr/bin/env python3
import rospy
from std_msgs.msg import String

rospy.init_node('motor_controller')
pub = rospy.Publisher('/motor_commands', String, queue_size=10)

while not rospy.is_shutdown():
    cmd = input("Enter command (forward, backward, left, right, stop): ")
    pub.publish(cmd)
    rospy.loginfo(f"Sent: {cmd}")
