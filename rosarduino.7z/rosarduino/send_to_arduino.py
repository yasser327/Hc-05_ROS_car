#!/usr/bin/env python3
import rospy
from std_msgs.msg import String

rospy.init_node('ros_to_arduino')
pub = rospy.Publisher('/chatter', String, queue_size=10)
rate = rospy.Rate(1)  # Send data every 1 second

while not rospy.is_shutdown():
    msg = String()
    msg.data = "Hello from ROS!"
    pub.publish(msg)
    rospy.loginfo(f"Sent: {msg.data}")
    rate.sleep()
